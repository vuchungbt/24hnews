const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const cookieParser = require('cookie-parser');
const { authMiddleware } = require('./middleware/auth');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Kết nối MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/news-website')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware để kiểm tra user đã đăng nhập chưa
app.use(async (req, res, next) => {
  try {
    const token = req.cookies.token;
    if (token) {
      const jwt = require('jsonwebtoken');
      const User = require('./models/User');
      
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.userId);
      
      if (user) {
        req.user = user;
      }
    }
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    next();
  }
});

// Routes
app.use('/', require('./routes/home'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/news', require('./routes/news'));
app.use('/api/categories', require('./routes/categories'));
app.use('/admin', authMiddleware, require('./routes/admin'));

// Error handling
app.use((req, res) => {
  res.status(404).render('error', { message: 'Trang không tồn tại' });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { message: 'Lỗi máy chủ' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
