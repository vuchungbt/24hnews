const express = require('express');
const router = express.Router();
const News = require('../models/News');
const Category = require('../models/Category');
const User = require('../models/User');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');
const bcrypt = require('bcryptjs');
const slugify = require('slugify');

// Middleware để kiểm tra quyền admin
router.use(authMiddleware, adminMiddleware);

// Trang dashboard
router.get('/dashboard', async (req, res) => {
  try {
    // Đếm số lượng người dùng
    const userCount = await User.countDocuments();
    
    // Đếm số lượng tin tức theo trạng thái
    const totalNews = await News.countDocuments();
    const publishedNews = await News.countDocuments({ status: 'published' });
    const draftNews = await News.countDocuments({ status: 'draft' });
    
    // Đếm số lượng danh mục
    const categoryCount = await Category.countDocuments();
    
    // Lấy 5 bài viết mới nhất
    const latestNews = await News.find()
      .populate('category')
      .sort({ createdAt: -1 })
      .limit(5);
    
    // Lấy 5 người dùng mới nhất
    const latestUsers = await User.find()
      .sort({ createdAt: -1 })
      .limit(5);
    
    // Tạo đối tượng stats để truyền vào view
    const stats = {
      users: userCount,
      totalNews: totalNews,
      publishedNews: publishedNews,
      draftNews: draftNews,
      categories: categoryCount
    };
    
    res.render('admin/dashboard', {
      user: req.user,
      stats,
      latestNews,
      latestUsers,
      title: 'Bảng điều khiển'
    });
  } catch (error) {
    console.error(error);
    res.status(500).render('error', { 
      message: 'Lỗi máy chủ',
      user: req.user
    });
  }
});

// Trang quản lý danh mục
router.get('/categories', async (req, res) => {
  try {
    const categories = await Category.find().sort({ name: 1 });
    
    res.render('admin/categories', {
      categories,
      user: req.user,
      title: 'Quản lý danh mục'
    });
  } catch (error) {
    console.error(error);
    res.status(500).render('error', { 
      message: 'Lỗi máy chủ',
      user: req.user
    });
  }
});

// Tạo danh mục mới
router.post('/categories/create', async (req, res) => {
  try {
    const { name, description } = req.body;
    
    // Tạo slug từ tên danh mục
    const slug = slugify(name, {
      lower: true,
      strict: true,
      locale: 'vi'
    });
    
    // Kiểm tra slug đã tồn tại
    const existingCategory = await Category.findOne({ slug });
    if (existingCategory) {
      req.flash('error', 'Tên danh mục đã tồn tại');
      return res.redirect('/admin/categories');
    }
    
    const newCategory = new Category({
      name,
      description,
      slug
    });
    
    await newCategory.save();
    req.flash('success', 'Tạo danh mục thành công');
    res.redirect('/admin/categories');
  } catch (error) {
    console.error(error);
    req.flash('error', 'Lỗi khi tạo danh mục');
    res.redirect('/admin/categories');
  }
});

// Cập nhật danh mục
router.post('/categories/edit/:id', async (req, res) => {
  try {
    const { name, description } = req.body;
    const category = await Category.findById(req.params.id);
    
    if (!category) {
      req.flash('error', 'Không tìm thấy danh mục');
      return res.redirect('/admin/categories');
    }
    
    // Nếu tên thay đổi, cập nhật slug
    if (name !== category.name) {
      const slug = slugify(name, {
        lower: true,
        strict: true,
        locale: 'vi'
      });
      
      // Kiểm tra slug đã tồn tại
      const existingCategory = await Category.findOne({ 
        slug, 
        _id: { $ne: category._id } 
      });
      
      if (existingCategory) {
        req.flash('error', 'Tên danh mục đã tồn tại');
        return res.redirect('/admin/categories');
      }
      
      category.slug = slug;
    }
    
    category.name = name;
    category.description = description;
    
    await category.save();
    req.flash('success', 'Cập nhật danh mục thành công');
    res.redirect('/admin/categories');
  } catch (error) {
    console.error(error);
    req.flash('error', 'Lỗi khi cập nhật danh mục');
    res.redirect('/admin/categories');
  }
});

// Xóa danh mục
router.get('/categories/delete/:id', async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);
    
    if (!category) {
      req.flash('error', 'Không tìm thấy danh mục');
      return res.redirect('/admin/categories');
    }
    
    // Kiểm tra xem có bài viết nào thuộc danh mục này không
    const newsCount = await News.countDocuments({ category: category._id });
    if (newsCount > 0) {
      req.flash('error', `Không thể xóa danh mục này vì có ${newsCount} bài viết liên quan`);
      return res.redirect('/admin/categories');
    }
    
    await Category.findByIdAndDelete(req.params.id);
    req.flash('success', 'Xóa danh mục thành công');
    res.redirect('/admin/categories');
  } catch (error) {
    console.error(error);
    req.flash('error', 'Lỗi khi xóa danh mục');
    res.redirect('/admin/categories');
  }
});

// Trang quản lý tin tức
router.get('/news', async (req, res) => {
  try {
    const news = await News.find()
      .populate('category')
      .populate('author', 'username')
      .sort({ createdAt: -1 });
    
    const categories = await Category.find().sort({ name: 1 });
    
    res.render('admin/news-management', {
      news,
      categories,
      user: req.user,
      title: 'Quản lý tin tức'
    });
  } catch (error) {
    console.error(error);
    res.status(500).render('error', { 
      message: 'Lỗi máy chủ',
      user: req.user
    });
  }
});

// Trang quản lý người dùng
router.get('/users', async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    
    res.render('admin/users', {
      users,
      user: req.user,
      title: 'Quản lý người dùng'
    });
  } catch (error) {
    console.error(error);
    res.status(500).render('error', { 
      message: 'Lỗi máy chủ',
      user: req.user
    });
  }
});

// Tạo người dùng mới
router.post('/users/create', async (req, res) => {
  try {
    const { username, email, password, role } = req.body;
    
    // Kiểm tra username và email đã tồn tại
    const existingUser = await User.findOne({
      $or: [{ username }, { email }]
    });
    
    if (existingUser) {
      req.flash('error', 'Tên đăng nhập hoặc email đã tồn tại');
      return res.redirect('/admin/users');
    }
    
    // Mã hóa mật khẩu
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    const newUser = new User({
      username,
      email,
      password: hashedPassword,
      role: role || 'user'
    });
    
    await newUser.save();
    req.flash('success', 'Tạo người dùng thành công');
    res.redirect('/admin/users');
  } catch (error) {
    console.error(error);
    req.flash('error', 'Lỗi khi tạo người dùng');
    res.redirect('/admin/users');
  }
});

// Cập nhật người dùng
router.post('/users/edit/:id', async (req, res) => {
  try {
    const { username, email, role, password } = req.body;
    const user = await User.findById(req.params.id);
    
    if (!user) {
      req.flash('error', 'Không tìm thấy người dùng');
      return res.redirect('/admin/users');
    }
    
    // Kiểm tra username và email đã tồn tại
    if (username !== user.username || email !== user.email) {
      const existingUser = await User.findOne({
        $or: [
          { username, _id: { $ne: user._id } },
          { email, _id: { $ne: user._id } }
        ]
      });
      
      if (existingUser) {
        req.flash('error', 'Tên đăng nhập hoặc email đã tồn tại');
        return res.redirect('/admin/users');
      }
    }
    
    user.username = username;
    user.email = email;
    user.role = role;
    
    // Cập nhật mật khẩu nếu có
    if (password && password.trim() !== '') {
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);
    }
    
    await user.save();
    req.flash('success', 'Cập nhật người dùng thành công');
    res.redirect('/admin/users');
  } catch (error) {
    console.error(error);
    req.flash('error', 'Lỗi khi cập nhật người dùng');
    res.redirect('/admin/users');
  }
});

// Xóa người dùng
router.get('/users/delete/:id', async (req, res) => {
  try {
    // Không cho phép xóa chính mình
    if (req.params.id === req.user.id) {
      req.flash('error', 'Không thể xóa tài khoản của chính mình');
      return res.redirect('/admin/users');
    }
    
    const user = await User.findById(req.params.id);
    
    if (!user) {
      req.flash('error', 'Không tìm thấy người dùng');
      return res.redirect('/admin/users');
    }
    
    await User.findByIdAndDelete(req.params.id);
    req.flash('success', 'Xóa người dùng thành công');
    res.redirect('/admin/users');
  } catch (error) {
    console.error(error);
    req.flash('error', 'Lỗi khi xóa người dùng');
    res.redirect('/admin/users');
  }
});

module.exports = router;
